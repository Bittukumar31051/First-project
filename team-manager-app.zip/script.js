const scriptURL = 'YOUR_WEB_APP_URL'; // Replace with your deployed Apps Script URL

document.querySelectorAll('form').forEach(form => {
  form.addEventListener('submit', async e => {
    e.preventDefault();

    const sheet = form.dataset.sheet;
    const formData = new FormData(form);
    formData.append("sheet", sheet);

    const res = await fetch(scriptURL, {
      method: 'POST',
      body: formData
    });

    const text = await res.text();
    alert(text === 'Success' ? "Data saved!" : "Error: " + text);
    form.reset();
  });
});
